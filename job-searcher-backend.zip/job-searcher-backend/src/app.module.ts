import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { JobCategoriesModule } from './jobCategories/job-categories.module';
import { countriesModule } from './countries/countries.module';
import { LatestnewsModule } from './latestnews/latestnews.module';
import { JobsModule } from './jobs/jobs.module';
import { CandidatesModule } from './candidates/candidates.module';

@Module({
  imports: [MongooseModule.forRoot('mongodb+srv://nader:nader@cluster0.im97q6j.mongodb.net/job-searcher', { useNewUrlParser: true }), JobCategoriesModule, countriesModule, LatestnewsModule, JobsModule, CandidatesModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule { }
