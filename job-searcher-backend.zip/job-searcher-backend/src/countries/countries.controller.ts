import { Controller, Get } from '@nestjs/common';
import { countriesService } from './countries.service';

@Controller('countries')
export class countriesController {
  constructor(private readonly countriesService: countriesService) { }

  @Get()
  async findAll(): Promise<any> {
    const Countries = await this.countriesService.findAll();
    return Countries
  }
}
