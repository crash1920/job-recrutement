import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { countriesController } from './countries.controller';
import { countriesSchema } from './countries.model';
import { countriesService } from './countries.service';

@Module({
  imports: [MongooseModule.forFeature([{ name: 'countries', schema: countriesSchema }])],
  controllers: [countriesController],
  providers: [countriesService],
})
export class countriesModule { }
