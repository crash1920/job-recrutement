import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type countriesDocument = countries & Document;

@Schema()
export class countries {
  @Prop()
  _id: number;

  @Prop()
  countryName: string;

}

export const countriesSchema = SchemaFactory.createForClass(countries);
