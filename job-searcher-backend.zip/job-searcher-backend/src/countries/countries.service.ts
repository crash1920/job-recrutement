import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { countries, countriesDocument } from './countries.model';

@Injectable()
export class countriesService {
  constructor(@InjectModel(countries.name) private readonly countriesModel: Model<countriesDocument>) { }

  async findAll(): Promise<countries[]> {
    const Countries = await this.countriesModel.find().exec();
    return Countries;
  }
}
