import { Controller, Get } from '@nestjs/common';
import { LatestnewsService } from './latestnews.service';

@Controller('latestNews')
export class LatestnewsController {
  constructor(private readonly LatestnewsService: LatestnewsService) { }

  @Get()
  async findAll(): Promise<any> {
    const latestNews = await this.LatestnewsService.findAll();
    return latestNews

  }
}
