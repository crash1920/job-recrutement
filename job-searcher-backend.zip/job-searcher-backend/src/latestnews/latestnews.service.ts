import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { latestnews, latestnewsDocument } from './latestnews.model';

@Injectable()
export class LatestnewsService {
  constructor(@InjectModel(latestnews.name) private readonly latestnewsModel: Model<latestnewsDocument>) { }

  async findAll(): Promise<latestnews[]> {
    const latestNews = await this.latestnewsModel.find().exec();
    return latestNews;
  }
}
