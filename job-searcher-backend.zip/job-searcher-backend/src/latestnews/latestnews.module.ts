import { Module } from '@nestjs/common';
import { LatestnewsController } from './latestnews.controller';
import { LatestnewsService } from './latestnews.service';
import { MongooseModule } from '@nestjs/mongoose';
import { latestnewsSchema } from './latestnews.model';

@Module({
  imports: [MongooseModule.forFeature([{ name: 'latestnews', schema: latestnewsSchema }])],
  controllers: [LatestnewsController],
  providers: [LatestnewsService]
})
export class LatestnewsModule { }
