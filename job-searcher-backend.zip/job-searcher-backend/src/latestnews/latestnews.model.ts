import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type latestnewsDocument = latestnews & Document;

@Schema()
export class latestnews {
  @Prop()
  _id: number;

  @Prop()
  date: string;

  @Prop()
  newsTitle: string;

  @Prop()
  description: string;

  @Prop()
  newsImage: string;

}

export const latestnewsSchema = SchemaFactory.createForClass(latestnews);
