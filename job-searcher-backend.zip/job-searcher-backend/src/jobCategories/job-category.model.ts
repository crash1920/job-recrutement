import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type jobcategoriesDocument = jobcategories & Document;

@Schema()
export class jobcategories {
  @Prop()
  _id: number;

  @Prop()
  name: string;

  @Prop()
  openings: number;
}

export const jobcategoriesSchema = SchemaFactory.createForClass(jobcategories);
