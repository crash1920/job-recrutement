import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { jobcategoriesSchema } from './job-category.model';
import { JobCategoriesController } from './job-categories.controller';
import { JobCategoriesService } from './job-categories.service';

@Module({
  imports: [MongooseModule.forFeature([{ name: 'jobcategories', schema: jobcategoriesSchema }])],
  controllers: [JobCategoriesController],
  providers: [JobCategoriesService],
})
export class JobCategoriesModule { }
