import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { jobcategories, jobcategoriesDocument } from './job-category.model';

@Injectable()
export class JobCategoriesService {
  constructor(@InjectModel(jobcategories.name) private readonly jobcategoriesModel: Model<jobcategoriesDocument>) { }

  async findAll(): Promise<jobcategories[]> {
    const jobCategories = await this.jobcategoriesModel.find().exec();
    return jobCategories;
  }
}
