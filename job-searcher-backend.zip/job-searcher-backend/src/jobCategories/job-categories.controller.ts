import { Controller, Get } from '@nestjs/common';
import { JobCategoriesService } from './job-categories.service';

@Controller('jobCategories')
export class JobCategoriesController {
  constructor(private readonly jobCategoriesService: JobCategoriesService) { }

  @Get()
  async findAll(): Promise<any> {
    const jobCategories = await this.jobCategoriesService.findAll();
    return jobCategories

  }
}
