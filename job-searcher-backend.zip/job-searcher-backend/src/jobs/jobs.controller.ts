import { Controller, Get, Param } from '@nestjs/common';
import { JobsService } from './jobs.service';
import { jobs, jobsDocument } from './jobs.model';
@Controller('jobs')
export class JobsController {
  constructor(private readonly jobsService: JobsService) { }

  @Get(':id')
  async findById(@Param('id') jobId: string): Promise<any> {
    const job = await this.jobsService.findById(jobId);
    return job

  }
  @Get()
  async findAll(): Promise<any> {
    const jobs = await this.jobsService.findAll();
    const jobsInfo = jobs.map(job => ({
      _id: job._id,
      jobCategory: job.jobCategory,
      jobTitle: job.jobTitle,
      city: job.city,
      time: job.time,
      type: job.type,
      logo: job.logo,
    }));
    return jobsInfo;
  }


}
