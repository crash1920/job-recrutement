import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { Document } from 'mongoose';
import { jobcategories } from 'src/jobCategories/job-category.model';

export type jobsDocument = jobs & Document;

@Schema()
export class jobs {
  @Prop()
  _id: number;

  @Prop()
  jobTitle: string;

  @Prop()
  city: string;

  @Prop()
  jobCategory: {
    _id: number,
    name: string,
    openings: number
  }[];

  @Prop()
  type: string;

  @Prop()
  time: string;

  @Prop()
  logo: string;

  @Prop()
  jobInformation: {
    category: { label: string; value: string }[];
    workShift: { value: string; label: string }[];
    postedOn: { label: string; value: string }[];
    openings: { value: string; label: string }[];
    jobLevel: { label: string; value: string }[];
    jobXp: { value: string; label: string }[];
  }[];

  @Prop()
  jobSkills: { title: string; _id: number }[];
}

export const JobSchema = SchemaFactory.createForClass(jobs);
