import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { jobs, jobsDocument } from './jobs.model';

@Injectable()
export class JobsService {
  constructor(@InjectModel(jobs.name) private readonly jobsModel: Model<jobsDocument>) { }

  async findAll(): Promise<jobs[]> {
    return this.jobsModel.find().populate('jobCategory').exec();
  }

  async findById(jobId: string): Promise<jobs> {
    const job = await this.jobsModel.findById(jobId).exec();
    return job;
  }

  async create(job: jobs): Promise<jobs> {
    const createdJob = new this.jobsModel(job);
    return createdJob.save();
  }

  async update(jobId: string, job: jobs): Promise<jobs> {
    const updatedJob = await this.jobsModel.findByIdAndUpdate(jobId, job, { new: true });
    return updatedJob;
  }

  async delete(jobId: string): Promise<void> {
    await this.jobsModel.findByIdAndDelete(jobId);
  }
}
