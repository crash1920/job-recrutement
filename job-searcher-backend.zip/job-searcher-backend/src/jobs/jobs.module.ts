import { Module } from '@nestjs/common';
import { JobsController } from './jobs.controller';
import { JobsService } from './jobs.service';
import { JobSchema } from './jobs.model';
import { MongooseModule } from '@nestjs/mongoose';

@Module({
  imports: [MongooseModule.forFeature([{ name: 'jobs', schema: JobSchema }])],
  controllers: [JobsController],
  providers: [JobsService]
})
export class JobsModule { }
