import { Controller, Get, Param } from '@nestjs/common';
import { CandidatesService } from './candidates.service';

@Controller('candidates')
export class CandidatesController {
  constructor(private readonly candidatesService: CandidatesService) { }


  @Get(':id')
  async findById(@Param('id') candidateId: string): Promise<any> {
    const candidate = await this.candidatesService.findById(candidateId);
    return candidate

  }

  @Get()
  async findAll(): Promise<any> {
    const candidates = await this.candidatesService.findAll();
    const candidateInfo = candidates.map(candidate => ({
      _id: candidate._id,
      firstName: candidate.firstName,
      lastName: candidate.lastName,
      city: candidate.city,
      commune: candidate.commune,
      jobTitle: candidate.jobTitle,
      photoCandidat: candidate.photoCandidat,
      facebookLink: candidate.facebookLink,
      githubLink: candidate.githubLink,
      twitterLink: candidate.twitterLink
    }));
    return candidateInfo;
  }

  // @Get()
  // async findAll(): Promise<any> {
  //   const candidates = await this.candidatesService.findAll();
  //   return candidates

  // }
}
