import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type CandidatesDocument = candidates & Document;

@Schema()
export class candidates {
  @Prop()
  _id: number;

  @Prop()
  firstName: string;

  @Prop()
  lastName: string;

  @Prop()
  email: string;

  @Prop()
  city: string;

  @Prop()
  commune: string;

  @Prop()
  jobTitle: string;

  @Prop()
  twitterLink: string;

  @Prop()
  facebookLink: string;

  @Prop()
  githubLink: string;

  @Prop()
  photoCandidat: string;

  @Prop({ type: [{ _id: Number, title: String, percentage: Number }] })
  skills: { _id: number, title: string, percentage: number }[];

  @Prop({ type: [{ debut: String, fin: String, xpTitle: String, university: String }] })
  educationAndExperience: { debut: string, fin: string, xpTitle: string, university: string }[];

  @Prop({ type: [{ photo: String }] })
  portfolio: { photo: string }[];

  @Prop()
  customFields: {
    birthCity: { label: string, value: string }[],
    jobXp: { label: string, value: string }[],
    familyMembers: { label: string, value: string }[],
    searchingForJob: { label: string, value: string }[],
    martialStatus: { label: string, value: string }[],
    JoiningDate: { label: string, value: string }[]
  }[];
}

export const CandidateSchema = SchemaFactory.createForClass(candidates);
