import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { candidates, CandidatesDocument } from './candidates.model';

@Injectable()
export class CandidatesService {
  constructor(@InjectModel(candidates.name) private readonly candidatesModel: Model<CandidatesDocument>) { }

  async findAll(): Promise<candidates[]> {
    const allCandidates = await this.candidatesModel.find().exec();
    return allCandidates;
  }

  async findById(id: string): Promise<candidates> {
    const candidate = await this.candidatesModel.findById(id).exec();
    return candidate;
  }

  async create(newCandidate: candidates): Promise<candidates> {
    const createdCandidate = new this.candidatesModel(newCandidate);
    await createdCandidate.save();
    return createdCandidate;
  }

  async update(id: string, updatedCandidate: candidates): Promise<candidates> {
    const existingCandidate = await this.candidatesModel.findByIdAndUpdate(id, updatedCandidate, { new: true }).exec();
    return existingCandidate;
  }

  async delete(id: string): Promise<void> {
    await this.candidatesModel.findByIdAndDelete(id).exec();
  }
  async extractInfo(id: string): Promise<{ firstName: string, lastName: string, city: string, commune: string, jobTitle: string, photoCandidat: string, facebookLink: string, githubLink: string, twitterLink: string }> {
    const candidate = await this.candidatesModel.findById(id).exec();
    const { firstName, lastName, city, commune, jobTitle, photoCandidat, facebookLink, githubLink, twitterLink } = candidate;
    return { firstName, lastName, city, commune, jobTitle, photoCandidat, facebookLink, githubLink, twitterLink };
  }
}
